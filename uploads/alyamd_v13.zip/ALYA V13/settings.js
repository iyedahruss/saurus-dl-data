const chalk = require("chalk")
const fs = require("fs")
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = false //auto block 212 (true to on, false to off)
global.wlcm = false
global.autokickmorroco = false //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)
global.autoreactsw = false
global.botMute = false // false = ON (merespon semua), true = OFF

//===============SETTING MENU==================\\
global.channel = '120363429190136593@newsletter'
global.gc = '120363421179070899@g.us'
global.channeln = 'Alya Chan Official </>' 
//===============SETTING MENU==================\\
global.thumbnail = 'https://raw.githubusercontent.com/yuusuke1101/Yuugames/refs/heads/main/IMG-20251228-WA0077.jpg'
global.thumbnailvid = 'https://raw.githubusercontent.com/yuusuke1101/Yuugames/refs/heads/main/alya1.mp4' //untuk ganti thumbnail menu wajib video ya
global.welcomeBg = 'https://i.ibb.co/4YBNyvP/mountain-sunset.jpg';
global.goodbyeBg = 'https://i.ibb.co/4YBNyvP/images-76.jpg';
global.qris = 'https://raw.githubusercontent.com/yuusuke1101/Yuugames/refs/heads/main/IMG-20260408-WA0414.jpg';
global.videothumb = 'https://raw.githubusercontent.com/yuusuke1101/Yuugames/refs/heads/main/alya1.mp4' //buat video/gif di allmenunya ngab wkwk
global.music = 'https://c.termai.cc/a194/YMx.mp3'
global.ig = 'ryuusuke_id'
global.tele = 'Ryuusuke_offc'
global.ttowner = '@yuusuke_yamada_1101'
global.ownername = 'Yuusuke/Ryuusuke'
global.owner = ['62895639043495'] //ganti juga di database/owner.json
global.ownernomer = '62895639043495' //ganti juga di database/owner.json
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
global.telegramToken = '7815633108:AAG4rGswoE_8_z6F-uKmME2GRX9SMnhKo-k'
global.aiso = [
    'AIzaSyBhUYKWmbG8BpGsBsm2QiEBzJhufdSwq1w',
    'AIzaSyDOPNhY2hIMnYPaUNRpHDmhMR04xau18xE',
    'AIzaSyCpX7QkYD4uKMxg3AaQjffWV8M6ZixfNsk',
    'AIzaSyB38oowbo9Q5hBsvgbx0q3BLtRdF9A_l-U',
    'AIzaSyAkO0aCzjVkNNQah_twiwWenC4vc6QBhvs',
    'AIzaSyAJhP3ffhBXYY_h5-OUFjLVbWGZWDvoIOs',
    'AIzaSyAF-DA3wbbhLOZweeoNXQ8vO1ULVOVKCsE',
    'AIzaSyBeNgb-GOFYR5f2q5UY13AUpWmDcN8ziI4'
    ]
global.api = {};
global.api.reactch = [
    'e462084f2a053697dc58d24aa0d42ff14b230f2b74c6ae7fe4d4674a764d1c42',
    '03ba12b364de7152418924027d166731148c4c23cc22916588369acb3498a2e7',
    'e40bf7cbaca4e246a0273b48bdb56c4079f8fe537b7739c5b9225b0b96079544',
	'4a84210413ac6675cf51c1f975a716eae3753c479818f173836bacc0eaea4e2c',
];
//========================setting Payment=====================\\
global.nodana = '0895393336779' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '-' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '-'// KOSONG KAN JIKA TIDAK ADA
//==================setting Payment Name===========================\\
global.andana = 'Cari sendiri.' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '' // KOSONG KAN JIKA TIDAK ADA
//BATAS//
global.settings = {
    autoreact: true
}
// Pick random emoji react status
global.emoji = [
    "🥶",
    "🙄",
    "😳",
    "😒",
    "🥰",
    "😎",
    "🫣",
    "😍",
    "😨",
    "😁",
    "👀",
    "👿",
    "🤖",
    "😮"
]
//==================setting bot===========================\\
global.botname = "© Alya Chan Assisten"
global.ownernumber = '62895639043495'
global.botnumber = '66961653473'
global.ownername = 'Sauruslord'
global.ownerNumber = ["62895639043495@s.whatsapp.net"]
global.ownerweb = "https://getdl.space"
global.websitex = ""
global.wagc = "https://chat.whatsapp.com/DpuIfQNn4WZGG4O0YtDn7S"
global.saluran = "https://whatsapp.com/channel/0029Vb6rCGN1iUxVlXtqp707"
global.themeemoji = '🏞️'
global.wm = "Alya Asisten"
global.botscript = 'Dah gede nyari sc 🗿🖕' //script link
global.packname = "Alya chan"
global.author = "\n\nDibuat Oleh Asisten Alya\nowner by: Saurus"
global.creator = "62895639043495@s.whatsapp.net"
//======================== CPANEL FITUR ===========================\\
global.domain = '' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_rBcXGJhiY4FHkclS6xVVcPk5gu5tGMUTfn6PWhEIsyq' // Isi Apikey Plta Lu
global.capikey = 'ptlc_dHqgrA1oZZ0n6AA4hiT2uCKGKHpKxU5xjL1bxAJPKDx' // Isi Apikey Pltc Lu
//=========================================================//
global.apiDigitalOcean = "-"
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah

global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
//===========================//
global.virtuSimApiKey = 'k6R8Zfw1xGVBdgPvODLW5hNyuS'
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // 
global.nodes = '2'
global.location3 = '1' // 
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//
global.mess = {
   wait: "Sabar dong! 💢 Jangan buru-buru, aku lagi proses nih! Bukan berarti aku lambat ya! 😤",
   success: "Tuh, udah selesai! 🙄 Jangan lupa bilang makasih, baka!",
   on: "Hmph, ya sudah! Fiturnya sudah aku nyalain ya! 😒",
   off: "Puas? Fiturnya udah aku matiin. Jangan ganggu aku dulu! 😴",
   query: {
       text: "Duh, kamu pelupa banget sih! 🙄 Masukin teksnya dong, aku kan bukan dukun yang bisa baca pikiranmu! 💢",
       link: "Mana link-nya?! 😤 Aku nggak bisa jalan kalau kamu nggak kasih link yang bener! Bikin repot aja!",
   },
   error: {
       fitur: "Hah?! Eror?! 💢 Ini pasti gara-gara kamu yang aneh-aneh! Sana laporin ke Ryuusuke (6283166570663) biar dia yang urus! 😤",
   },
  only: {
    group: "Hmph! 😤 Fitur ini cuma bisa dipake di dalam grup ya! Jangan sok asik mau pake di sini!",
    private: "Duh, nggak usah bawa-bawa fitur ini ke grup! 🙄 Chat pribadi sama aku aja kalau mau pake ini, baka!",
    owner: "Heh! 💢 Kamu pikir kamu siapa? Cuma *Ryuusuke* yang boleh perintah-perintah aku pake fitur ini!",
    admin: "Sadar diri dong! 😤 Fitur ini khusus buat Admin grup aja. Kamu kan bukan siapa-siapa di sini!",
    badmin: "Gimana aku mau kerja kalau aku nggak dijadiin Admin? 💢 Cepetan jadiin aku Admin dulu, baru aku bantuin!",
    premium: "Jangan mimpi bisa pake fitur ini kalau masih gratisan! 😒 Beli Premium sana di 6283166570663... bukan berarti aku butuh uangmu ya! 😤",
}
}
//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.sessionName = 'Alyachan'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "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"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'
global.spotify_client_id = 'f8d0d37c39cc4ed68950b72fa9f85be9'
global.spotify_client_secret = '8531d4c9fa6745a0b56b9c8023bd75a0'
global.spotify_backup_token = 'BQD8JJ8Jn7gYTHo59K9o4hNinxguZO1e_cRKjq4kOjIzMYT4yg6gHK-Wymj1--fC2TGUJpQ6JZyFog8n--DnU8tPNNf5DrajUV-yYx8LZDU3RBU1owhs0sR-wPl0lcySrMdwwTSDbtlFRTNBRbOtjcXQqDQGY_QA23EavKT9u4nuAf7ANZju-hR9QJ1pI0DVE09vCeMBoTKX7u8LcOvX94Yp23s4Vd35OZM4RAhI-fAO1NsbFP8TKSwmC5p0y-cb23pp7z4rSQCpN42OPTveWBWyzLjiDqu6jZynBJ0LgEpAmFlmLmuNC7Uy9pjVgHeM71Bwq4k'
global.supaurl = 'https://uzyzpgujphlmesbmcwca.supabase.co'
global.supakey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV6eXpwZ3VqcGhsbWVzYm1jd2NhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwNjQwMjcsImV4cCI6MjA3MDY0MDAyN30.SwjgDAcEDLvjmzKzxHPdtHdjLbH1Zsr20MbPI4s6F94'


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
