/*╔═══════════════════════════════════════════════════════╗
 *║  🦖  LORD SAURUS EMPIRE
 *╟───────────────────────────────────────────────────────╢
 *║  🌐 Web      : https://saurusdev.cloud
 *║  ▶︎ YouTube  : https://www.youtube.com/@sauruskinggwuw
 *║  📡 Saluran  : https://whatsapp.com/channel/0029Vb8g2ZyH5JLykgHzVu2g
 *║  ✈︎ Telegram : @lordsaurus
 *║
 *║  ⚠︎ Jangan hapus watermark ini ya!
 *╚═══════════════════ © 2026 Lunar Saurus ═════════════════╝
 *
 *  File ini cuma isi teks kategori menu (global.menu*).
 */
import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

global.menuowner = `
╭─❐ *OWNER MENU* ❐─╮
┃ ➤ .getcase
┃ ➤ .getplugin
┃ ➤ .addcase
┃ ➤ .delcase
┃ ➤ .addplugin
┃ ➤ .delplugin
┃ ➤ .setnamabot
┃ ➤ .setbiobot
┃ ➤ .setppbot
┃ ➤ .setting
┃ ➤ .settingbot
┃ ➤ .self
┃ ➤ .public
┃ ➤ .autoread
┃ ➤ .autoreadsw
┃ ➤ .autojoingc
┃ ➤ .joingc
┃ ➤ .ping
┃ ➤ .runtime
┃ ➤ .addprem
┃ ➤ .delprem
┃ ➤ .addlimit
┃ ➤ .buyprem
┃ ➤ .buylimit
┃ ➤ .crm2
┃ ➤ .send
┃ ➤ .jadibot
┃ ➤ .delbot
╰────────────────╯
`

global.menugroup = `
╭─❐ *GROUP MENU* ❐─╮
┃ ➤ .promote
┃ ➤ .demote
┃ ➤ .kick
┃ ➤ .delete
┃ ➤ .leave
┃ ➤ .leave2
┃ ➤ .leavegc
┃ ➤ .leavegc2
┃ ➤ .join
┃ ➤ .hidetag
┃ ➤ .tagall
┃ ➤ .upswgc
┃ ➤ .swgc
┃ ➤ .swgrup
┃ ➤ .option
┃ ➤ .pin
╰────────────────╯
`

global.menustore = `
╭─❐ *STORE MENU* ❐─╮
┃ ➤ .dana
┃ ➤ .gopay
┃ ➤ .ovo
┃ ➤ .qris
┃ ➤ .cekprem
┃ ➤ .ceklimit
╰────────────────╯
`

global.menustk = `
╭─❐ *STICKER MENU* ❐─╮
┃ ➤ .sticker
┃ ➤ .stiker
┃ ➤ .smeme
┃ ➤ .sgif
┃ ➤ .qc
┃ ➤ .brat
┃ ➤ .bratvid
┃ ➤ .emojimix
┃ ➤ .toimg
╰────────────────╯
`

global.menuanime = `
╭─❐ *ANIME MENU* ❐─╮
┃ ➤ .waifu
╰────────────────╯
`

global.menucecan = `
╭─❐ *CECAN & COGAN MENU* ❐─╮
┃ ➤ .cosplayba
┃ ➤ .cosba
┃ ➤ .bluearchive
┃ ➤ .ba
╰────────────────╯
`

global.menusearch = `
╭─❐ *SEARCH MENU* ❐─╮
┃ ➤ .getpp
┃ ➤ .pinterest
┃ ➤ .iqc
┃ ➤ .remini
┃ ➤ .cekidch
╰────────────────╯
`

global.menudownload = `
╭─❐ *DOWNLOAD MENU* ❐─╮
┃ ➤ .play
┃ ➤ .capcut
┃ ➤ .igdl
┃ ➤ .mediafire
┃ ➤ .spotify
┃ ➤ .tiktok
┃ ➤ .tt
┃ ➤ .tt-dl
┃ ➤ .twitter
┃ ➤ .twitdl
╰────────────────╯
`

global.menumaker = `
╭─❐ *MAKER MENU* ❐─╮
┃ ➤ .removebg
┃ ➤ .hd
╰────────────────╯
`

global.menutolls = `
╭─❐ *TOOLS MENU* ❐─╮
┃ ➤ .toaudio
┃ ➤ .tovid
┃ ➤ .tovn
┃ ➤ .tourl
┃ ➤ .ambilq
┃ ➤ .setbio
┃ ➤ .setpp
┃ ➤ .tutor
┃ ➤ .tutorial
╰────────────────╯
`

global.menusticker = `
╭─❐ *STICKERS MENU* ❐─╮
┃ ➤ .brat
┃ ➤ .bratvid
┃ ➤ .sticker
┃ ➤ .stiker
┃ ➤ .smeme
┃ ➤ .qc
┃ ➤ .emojimix
┃ ➤ .toimg
╰────────────────╯
`

global.menubroadcast = `
╭─❐ *BROADCAST MENU* ❐─╮
┃ ➤ .jpm
┃ ➤ .jpmch
┃ ➤ .jpmht
┃ ➤ .jpmswgc
┃ ➤ .bljpm
┃ ➤ .autojpm
╰────────────────╯
`

global.menufun = `
╭─❐ *FUN MENU* ❐─╮
┃ ➤ .blockblast
┃ ➤ .akinator
╰────────────────╯
`

global.allmenu = `
${global.menuowner}
${global.menugroup}
${global.menubroadcast}
${global.menustore}
${global.menudownload}
${global.menusearch}
${global.menumaker}
${global.menutolls}
${global.menusticker}
${global.menufun}
${global.menuanime}
${global.menucecan}
`

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let file = __filename;
fs.watchFile(file, async () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${file}`));
    try {
        await import(`${file}?update=${Date.now()}`);
    } catch (err) {
        console.error(err);
    }
});