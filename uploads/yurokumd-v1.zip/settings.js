/*╔═══════════════════════════════════════════════════════╗
 *║  🦖  LORD SAURUS EMPIRE
 *╟───────────────────────────────────────────────────────╢
 *║  🌐 Web      : https://saurusdev.cloud
 *║  ▶︎ YouTube  : https://www.youtube.com/@sauruskinggwuw
 *║  📡 Saluran  : https://whatsapp.com/channel/0029Vb8g2ZyH5JLykgHzVu2g
 *║  ✈︎ Telegram : @lordsaurus
 *║
 *║  ⚠︎ Jangan hapus watermark ini ya!
 *╚═══════════════════ © 2026 Lunar Saurus ═════════════════╝
 */
import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath, pathToFileURL } from 'url';
import { dirname } from 'path';
import moment from "moment-timezone";

//——————————[ Config Owner ]——————————//
global.ownernumber = '62895639043495' // Ganti nomer mu
global.ownername = 'Saurus'

//——————————[ Config Bot ]——————————//
global.namabot = "Yuroku MD"
global.nomorbot = '66961653473' // Ganti no botmu
global.pair = "YUROKUMD"
global.version = '1.0.0'
global.prefix = '°zZ#$@+,.?=\'\'():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^'

// false = nonaktif, true = aktif
global.owneronly = true // true = self (hanya owner), false = public
global.autojoingc = false
global.autoreadsw = false
global.autoread = false

//——————————[ Config Sosmed ]——————————//
global.web = "https://saurusdev.cloud"
global.linkSaluran = "https://whatsapp.com/channel/0029Vb8g2ZyH5JLykgHzVu2g"
global.idSaluran = "120363429190136593@newsletter" // ⚠️ Ganti manual ke ID newsletter channel baru (bisa dicek pakai .cekidch di channel)
global.nameSaluran = "Saurus official"
global.ytChannel = "https://www.youtube.com/@sauruskinggwuw"
global.telegram = "@lordsaurus"

//——————————[ Config Wm ]——————————//
global.packname = `Dιвυαт σℓєн Yυяσкυ MD
⏰ ${moment.tz("Asia/Jakarta").format("HH:mm:ss")}
Sєωα вσт ρυѕнкσитαк? Cнαт: ${ownernumber}`
global.author = ``
global.foother = '© 2026 - Made By Saurus'

//——————————[ Config Payment ]——————————//
// Note : Kalau gada isi aja jadi false
global.dana = "0895393336779"
global.ovo = false
global.gopay = false
global.qris = "https://e.top4top.io/p_39129u6mz1.jpg"
global.an = {
    dana: "kepo",
    ovo: "nama_ovo",
    gopay: "nama_gopay"
}

//——————————[ Config Media ]——————————//
global.img = "https://cdn.synoxcloud.xyz/storage/tim9rqudgrdv.jpg"
global.thumbxm = "https://cdn.synoxcloud.xyz/storage/jmbrtjuh8sbm.png"
global.thumbbc = "https://raw.githubusercontent.com/iyedahruss/all-public-db/refs/heads/main/images/699c7cd6-e885-4e09-9400-c43431635b3f.png"
global.thumb = "https://raw.githubusercontent.com/iyedahruss/all-public-db/refs/heads/main/images/699c7cd6-e885-4e09-9400-c43431635b3f.png"
global.favicon = "https://am.saurusgege.my.id/assets/image/logo.png"
global.vnMenu = "./lib/assets/audio/saurusgtg.mp3"
global.noProfileImg = "https://i.ibb.co/6BRf4Rc/no-profile.png" // Default avatar kalau user gaada foto profil
global.defaultChannelImg = "https://files.catbox.moe/xpntd8.jpg" // Default thumbnail buat createchannel

//——————————[ Config Limit & Premium ]——————————//
global.limitDefault = 25 // Jatah limit gratis per hari, reset otomatis tiap jam 00.00 WIB
global.hargaLimit = 5000 // Harga per pembelian limit (ditampilkan di .buylimit, bukan dieksekusi otomatis)
global.hargaPrem = 10000 // Harga premium per hari (ditampilkan di .buyprem, bukan dieksekusi otomatis)
// Catatan: gambar QRIS untuk .buyprem / .buylimit sekarang pakai global.qris (di atas), tidak perlu variabel terpisah lagi

//——————————[ Config Broadcast ]——————————//
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 5000
global.namakontak = "AutoSave Yuroku MD"

//——————————[ Config Message ]——————————//
global.mess = {
  success: 'Sєℓєѕαι. Bєянαѕιℓ ∂ιєкѕєкυѕι.',
  wait: 'Tυиɢɢυ ѕєвєитαя. Aкυ ѕє∂αиɢ вєкєяנα...',
  admin: 'Kαмυ вυкαи A∂мιи ∂ι ѕιиι.',
  botAdmin: 'Aкυ вєℓυм мєиנα∂ι A∂мιи ∂ι Gяσυρ ιиι.',
  creator: 'Kαмυ ѕιαρα? Pєяιитαн ιиι нαиуα υитυк Oωиєякυ.',
  group: 'Nɢɢαк вιѕα ∂ι ѕιиι. Pαкαι ∂ι Gяσυρ.',
  private: 'Pαкαι ∂ι Cнαт Pяιвαт αנα.',
  error: 'Tєяנα∂ι Eяяσя. Cσвα ℓαɢι.',
  limit: 'Lιмιтмυ нαвιѕ. Iѕтιяαнαт ∂υℓυ уα.',
}


// *** message *** 
global.closeMsgInterval = 30; // 30 menit. maksimal 60 menit, minimal 1 menit
global.backMsgInterval = 2; // 2 jam. maksimal 24 jam, minimal 1 jam


//——————————[ Menu Kategori ]——————————//
import './source/menu-yurokumd.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
let file = __filename;
fs.watchFile(file, async () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${file}`));
    try {
        const module = await import(`${file}?update=${Date.now()}`); 
    } catch (err) {
        console.error(err);
    }
});